#ifndef SUS_H
#define SUS_H

#include <QMainWindow>
#include <QPushButton>
#include <QGridLayout>
#include <QLabel>
#include <vector>
#include "SUS_X_O_Board.h" // Include your game logic

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleCellClick();   // Handle board button clicks
    void startNewGame();      // Start a new game
    void setPlayerMode();     // Player vs Player mode

private:
    Ui::MainWindow *ui;
    void disableButtons();
    SUS_X_O_Board *board;     // Pointer to the game board logic
    QList<QPushButton*> buttons;
    QLabel *statusLabel;      // Label to show status messages
    QLabel *scoreLabel;       // Label to show scores
    char currentPlayer;       // Track the current player
    void Game();
    void updateBoard();       // Update the board display
    void checkGameState();    // Check win/draw conditions
};
#endif // SUS_H
