#ifndef ULTIMATETICTACTOE_H
#define ULTIMATETICTACTOE_H

#include "BoardGame_Classes.h"

class ultemate_X_O_Board : public Board<char> {
public:
    ultemate_X_O_Board(int r, int c) : Board<char>(r, c) {
        initializeBoard();
        currentPlayerSymbol = 'X';
    }

    bool gameOver = false;
    char mainboard[3][3];
    char board[9][9];

    void initializeBoard() override {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                mainboard[i][j] = '*';
            }
        }

        for (int i = 0; i < 9; ++i) {
            for (int j = 0; j < 9; ++j) {
                board[i][j] = '*';
            }
        }
    }

    bool checkWin(char board[3][3]) {
        for (int i = 0; i < 3; ++i) {
            if ((board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != '*') ||
                (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != '*')) {
                return true;
            }
        }

        if ((board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != '*') ||
            (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != '*')) {
            return true;
        }
        return false;
    }

    bool is_win(char currentPlayerSymbol) override {
        for (int i = 0; i < 3; ++i) {
            if (mainboard[i][0] != '*' && mainboard[i][0] == mainboard[i][1] && mainboard[i][1] == mainboard[i][2]) {
                return true;
            }
        }

        for (int i = 0; i < 3; ++i) {
            if (mainboard[0][i] != '*' && mainboard[0][i] == mainboard[1][i] && mainboard[1][i] == mainboard[2][i]) {
                return true;
            }
        }

        if (mainboard[0][0] != '*' && mainboard[0][0] == mainboard[1][1] && mainboard[1][1] == mainboard[2][2]) {
            return true;
        }
        if (mainboard[0][2] != '*' && mainboard[0][2] == mainboard[1][1] && mainboard[1][1] == mainboard[2][0]) {
            return true;
        }

        return false;
    }

    bool is_valid_move(int largeRow, int largeCol, int smallRow, int smallCol) {
        if (mainboard[largeRow][largeCol] != '*') {
            return false;
        }

        int globalRow = largeRow * 3 + smallRow;
        int globalCol = largeCol * 3 + smallCol;
        return board[globalRow][globalCol] == '*';
    }


    bool is_draw() override {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (mainboard[i][j] == '*') return false;
            }
        }
        return !is_win(' ');
    }

    bool checkDraw(char board[3][3]) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (board[i][j] == '*') {
                    return false;
                }
            }
        }
        return true;
    }
};

#endif
