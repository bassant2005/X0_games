#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    board(new ultemate_X_O_Board(3, 3)),
    currentPlayer('X') {

    ui->setupUi(this);
    ui->centralwidget->setStyleSheet("background-color: Gainsboro;");

    QGridLayout *grid = new QGridLayout();

    for (int i = 0; i < 9; ++i) {
        QVector<QPushButton *> row;
        for (int j = 0; j < 9; ++j) {
            QPushButton *button = new QPushButton();
            button->setFixedSize(50, 50);

            QString borderStyle = "font-size: 16px; border: 1px solid gray;";

            if (i % 3 == 0) borderStyle += "border-top: 3px solid black;";
            if (j % 3 == 0) borderStyle += "border-left: 3px solid black;";
            if (i == 8) borderStyle += "border-bottom: 3px solid black;";
            if (j == 8) borderStyle += "border-right: 3px solid black;";

            button->setStyleSheet(borderStyle);
            connect(button, &QPushButton::clicked, this, &MainWindow::handleCellClick);

            row.push_back(button);
            grid->addWidget(button, i, j);
        }
        buttons.push_back(row);
    }

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(grid);
    centralWidget->setStyleSheet("background-color: Gainsboro;");
    setCentralWidget(centralWidget);

    statusLabel = new QLabel("Player X's Turn", this);
    statusLabel->setStyleSheet("font-size: 18px; font-weight: bold;");
    ui->statusbar->addWidget(statusLabel);

    // Add label to indicate the colors for each player
    colorLabel = new QLabel(this);
    colorLabel->setText("<html><body><font size='4'>Player <font color='pink'>X</font> is <font color='pink'>pink</font>, Player <font color='orange'>O</font> is <font color='orange'>orange</font></font></body></html>");
    colorLabel->setStyleSheet("font-size: 16px; font-weight: bold;");
    ui->statusbar->addPermanentWidget(colorLabel);  // Add this label to the status bar

    startNewGame();
}

MainWindow::~MainWindow() {
    delete ui;
    delete board;
}

void MainWindow::startNewGame() {
    board->initializeBoard();
    currentPlayer = 'X';
    statusLabel->setText("Player X's Turn");
    updateBoard();

    for (auto &row : buttons) {
        for (auto &button : row) {
            button->setEnabled(true);
        }
    }
}

void MainWindow::handleCellClick() {
    QPushButton *button = qobject_cast<QPushButton *>(sender());

    int row = -1, col = -1;
    for (int i = 0; i < 9; ++i) {
        for (int j = 0; j < 9; ++j) {
            if (buttons[i][j] == button) {
                row = i;
                col = j;
                break;
            }
        }
        if (row != -1) break;
    }

    int largeRow = row / 3;
    int largeCol = col / 3;
    int smallRow = row % 3;
    int smallCol = col % 3;

    if (!board->is_valid_move(largeRow, largeCol, smallRow, smallCol)) {
        statusLabel->setText("Invalid move. Try again.");
        return;
    }

    board->board[row][col] = currentPlayer;
    button->setText(QString(currentPlayer));

    char subBoard[3][3];
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            subBoard[i][j] = board->board[largeRow * 3 + i][largeCol * 3 + j];
        }
    }

    if (board->checkWin(subBoard)) {
        board->mainboard[largeRow][largeCol] = currentPlayer;
        if (board->is_win(currentPlayer)) {
            statusLabel->setText(QString("Player %1 wins the game!").arg(currentPlayer));
            disableButtons();
            colorEntireBoard(currentPlayer);
            return;
        }

        // Change the background color of the buttons in the winning small board
        QString backgroundColor = (currentPlayer == 'X') ? "pink" : "orange";
        for (int i = largeRow * 3; i < (largeRow + 1) * 3; ++i) {
            for (int j = largeCol * 3; j < (largeCol + 1) * 3; ++j) {
                buttons[i][j]->setStyleSheet("background-color: " + backgroundColor + ";");
            }
        }
    }
    else if (board->checkDraw(subBoard)) {
        board->mainboard[largeRow][largeCol] = 'D';
        // Change the background color of the buttons in the draw small board to gray
        for (int i = largeRow * 3; i < (largeRow + 1) * 3; ++i) {
            for (int j = largeCol * 3; j < (largeCol + 1) * 3; ++j) {
                buttons[i][j]->setStyleSheet("background-color: gray;");
            }
        }
    }

    if (board->is_win(currentPlayer)) {
        statusLabel->setText(QString("Player %1 wins the game!").arg(currentPlayer));
        disableButtons();
        colorEntireBoard(currentPlayer);
        return;
    }

    if (board->is_draw()) {
        statusLabel->setText("The game is a draw!");
        disableButtons();
        return;
    }

    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    statusLabel->setText(QString("Player %1's Turn").arg(currentPlayer));
}

// New function to color the entire large board
void MainWindow::colorEntireBoard(char winner) {
    QString backgroundColor = (winner == 'X') ? "pink" : "orange";
    for (int i = 0; i < 9; ++i) {
        for (int j = 0; j < 9; ++j) {
            buttons[i][j]->setStyleSheet("background-color: " + backgroundColor + ";");
        }
    }
}

void MainWindow::updateBoard() {
    for (int i = 0; i < 9; ++i) {
        for (int j = 0; j < 9; ++j) {
            char symbol = board->board[i][j];
            buttons[i][j]->setText(symbol == '*' ? "" : QString(symbol));
        }
    }
}

void MainWindow::disableButtons() {
    for (auto &row : buttons) {
        for (auto &button : row) {
            button->setEnabled(false);
        }
    }
}

