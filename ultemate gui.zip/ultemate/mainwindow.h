#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QVector>
#include <QLabel>
#include <QGridLayout>
#include "UltimateTicTacToe.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleCellClick();
    void startNewGame();
    void disableButtons();

private:
    Ui::MainWindow *ui;
    ultemate_X_O_Board *board; // Game logic object
    QVector<QVector<QPushButton *>> buttons; // 9x9 button grid
    QLabel *statusLabel; // Display status (e.g., player turn, win/draw)
    QLabel *colorLabel;
    char currentPlayer;
    void colorEntireBoard(char winner);
    void updateBoard();
};

#endif // MAINWINDOW_H
