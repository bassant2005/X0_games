#include "SUS.h"
#include "ui_SUS.h"

#include "SUS.h"       // Header file for the MainWindow class
#include "ui_SUS.h"    // Automatically generated UI header file

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), currentPlayer('S') {
    ui->setupUi(this);

    // Set the background color of the central widget to light blue
    ui->centralwidget->setStyleSheet("background-color: Gainsboro;");

    // Initialize the game board
    board = new SUS_X_O_Board(3, 3);
    board->initializeBoard();

    // Set up buttons for the board
    QGridLayout *grid = new QGridLayout();
    for (int i = 0; i < 9; ++i) {
        QPushButton *button = new QPushButton();
        button->setFixedSize(100, 100);
        button->setStyleSheet("font-size: 24px;");
        connect(button, &QPushButton::clicked, this, &MainWindow::handleCellClick);
        buttons.push_back(button);
        grid->addWidget(button, i / 3, i % 3);
    }
    ui->centralwidget->setLayout(grid);

    // Set up labels and increase their font size
    statusLabel = new QLabel("Player S's Turn");
    scoreLabel = new QLabel("Player S: 0 | Player U: 0");

    colorLabel = new QLabel();
    colorLabel->setText("<html><body><font size='4'>Player <font color='pink'>S</font> is <font color='pink'>pink</font>, Player <font color='orange'>U</font> is <font color='orange'>orange</font></font></body></html>");

    // Style the labels to make them bigger
    statusLabel->setStyleSheet("font-size: 20px; font-weight: bold;");
    scoreLabel->setStyleSheet("font-size: 20px; font-weight: bold;");
    colorLabel->setStyleSheet("font-size: 20px; font-weight: bold;");

    ui->statusbar->addWidget(statusLabel);
    ui->statusbar->addPermanentWidget(scoreLabel);
    ui->statusbar->addPermanentWidget(colorLabel);

    // Connect menu actions
    connect(ui->actionNewgame, &QAction::triggered, this, &MainWindow::startNewGame);
    connect(ui->actionPlayer_vs_Playe, &QAction::triggered, this, &MainWindow::setPlayerMode);

    startNewGame();
}

MainWindow::~MainWindow() {
    delete ui;
    delete board;
}

void MainWindow::startNewGame() {
    board->initializeBoard();
    currentPlayer = 'S';
    statusLabel->setText("Player S's Turn");
    updateBoard();
}

void MainWindow::setPlayerMode() {
    startNewGame();
}

int player1 = 0;
int player2 = 0;

void MainWindow::handleCellClick() {
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    int index = buttons.indexOf(button);

    // Proceed if the move is valid
    if (board->is_valid_move(index + 1)) {
        board->update_board(index + 1, currentPlayer);
        board->countSUS(index + 1, currentPlayer);  // Assuming countSUS is part of your logic

        if(currentPlayer == 'U'){player2++;}
        else{player1++;}

        // Check the game state after the move
        checkGameState();

        // Switch players if the game is not over (the board is not full)
        if (!board->is_full()) {
            currentPlayer = (currentPlayer == 'S') ? 'U' : 'S';
            statusLabel->setText(QString("Player %1's Turn").arg(currentPlayer));
        }

        checkGameState();
        updateBoard();
    }
}

void MainWindow::checkGameState() {
    // Check if the game is over based on the board being full
    if (board->is_full()) {
        if (board->scorePlayer > board->scoreOpponent) {
            statusLabel->setText("Player S Wins!");
            colorEntireBoard('S');  // Color the entire board if Player S wins
        }
        else if (board->scorePlayer < board->scoreOpponent) {
            statusLabel->setText("Player U Wins!");
            colorEntireBoard('U');  // Color the entire board if Player U wins
        }
        else {
            statusLabel->setText("It's a Draw!");
        }
        disableButtons();  // Disable the buttons after the game ends
    }
}

void MainWindow::disableButtons() {
    for (auto &button : buttons) {
        button->setEnabled(false);  // Disable all buttons when the game ends
    }
}

void MainWindow::updateBoard() {
    for (int i = 0; i < 9; ++i) {
        int row = i / 3;
        int col = i % 3;

        // Use the existing `board` object (no need to create a new one)
        char symbol = board->getBoard()[row][col];  // Access the board's 2D array
        buttons[i]->setText(symbol == ' ' ? "" : QString(symbol));
    }
    scoreLabel->setText(QString("Player S: %1 | Player U: %2")
                            .arg(board->scorePlayer)
                            .arg(board->scoreOpponent));
}

void MainWindow::colorEntireBoard(char winner) {
    QString backgroundColor = (winner == 'S') ? "pink" : "orange";  // Set color based on winner
    for (auto &button : buttons) {
        button->setStyleSheet("background-color: " + backgroundColor + ";");
    }
}

