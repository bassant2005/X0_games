#ifndef SUS_X_O_BOARD_H
#define SUS_X_O_BOARD_H

#include "BoardGame_Classes.h"

class SUS_X_O_Board : public Board<char> {
public:
    char playerLetter = 'S';
    char opponentLetter = 'U';
    int scorePlayer = 0;
    int scoreOpponent = 0;

    SUS_X_O_Board(int r, int c) : Board<char>(r, c) {
        initializeBoard();
        srand(time(0));
    }

    void initializeBoard() override {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }
        }
    }

    bool is_valid_move(int position) override{
        int row = (position - 1) / 3;
        int col = (position - 1) % 3;
        return (position >= 1 && position <= 9 && board[row][col] != 'S' && board[row][col] != 'U');
    }


    bool is_win(char currentPlayerSymbol) override {
        // Check rows, columns, and diagonals for "SUS"
        for (int i = 0; i < 3; i++) {
            if ((this->board[i][0] == 'S' && this->board[i][1] == 'U' && this->board[i][2] == 'S') ||
                (this->board[0][i] == 'S' && this->board[1][i] == 'U' && this->board[2][i] == 'S')) {
                return true;
            }
        }
        // Diagonals
        if ((this->board[0][0] == 'S' && this->board[1][1] == 'U' && this->board[2][2] == 'S') ||
            (this->board[0][2] == 'S' && this->board[1][1] == 'U' && this->board[2][0] == 'S')) {
            return true;
        }
        return false;
    }

    bool update_board(int n, char symbol) override {
        if (n < 1 || n > 9) return false;
        int row = (n - 1) / 3;
        int col = (n - 1) % 3;
        if (this->board[row][col] != 'S' && this->board[row][col] != 'U') {
            this->board[row][col] = symbol;
            return true;
        }
        return false;
    }


    bool is_full(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] != 'S' && board[i][j] != 'U') return false;
            }
        }
        return true;
    }


    void countSUS(int position, char currentPlayerLetter) {
        int row = (position - 1) / 3;
        int col = (position - 1) % 3;
        int n_moves = 0;

        if (board[row][0] == 'S' && board[row][1] == 'U' && board[row][2] == 'S') {
            n_moves++;
        }

        if (board[0][col] == 'S' && board[1][col] == 'U' && board[2][col] == 'S') {
            n_moves++;
        }

        if (row == col) {
            if (board[0][0] == 'S' && board[1][1] == 'U' && board[2][2] == 'S') {
                n_moves++;
            }
        }

        if (row + col == 2) {
            if (board[0][2] == 'S' && board[1][1] == 'U' && board[2][0] == 'S') {
                n_moves++;
            }
        }

        if (currentPlayerLetter == playerLetter) {
            scorePlayer += n_moves;
        }

        else {
            scoreOpponent += n_moves;
        }
    }
    void display_count(){
        cout << "The board is full!\n";
        cout << "Player S's Score (" << playerLetter << "): " << scorePlayer << "\n";
        cout << "Player U's Score (" << opponentLetter << "): " << scoreOpponent << "\n";

        if (scorePlayer > scoreOpponent) {
            cout << "Player S wins!\n";
        }
        else if (scorePlayer < scoreOpponent) {
            cout << "Player U wins!\n";
        }
        else {
            cout << "It's a draw!\n";
        }
    }
};

#endif

